# bird
python ms_ssim/msssim_score.py \
        --image_folder ../Results/birds/birds_512_testing_num_10 \
        --h5_file 'birds_512_G_epoch_80.h5' \
        --evaluate_overall_score 
