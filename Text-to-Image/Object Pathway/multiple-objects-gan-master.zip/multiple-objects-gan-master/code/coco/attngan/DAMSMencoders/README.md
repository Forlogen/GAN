Put the pre-trained DAMSM model into a folder `coco`
